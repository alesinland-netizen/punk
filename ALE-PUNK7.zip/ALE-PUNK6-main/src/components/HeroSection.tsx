import { useRef, useEffect, useState } from "react";
import heroRider from "@/assets/hero-punk-rider.jpg";
import heroRebel from "@/assets/hero-punk-rebel.jpg";

const HERO_VIDEO_URL = "https://cdn.shopify.com/videos/c/o/v/78fcf174f11349f4aab1c6116ce171cd.mp4";

const banners = [
  {
    image: heroRider,
    title: "Punk Rider",
    cta: "Descubrí más",
    href: "#modelos",
  },
  {
    image: heroRebel,
    title: "Punk Rebel",
    cta: "Descubrí más",
    href: "#modelos",
  },
];

const HeroSection = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [showPlayButton, setShowPlayButton] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const attemptAutoplay = async () => {
      try {
        await video.play();
      } catch {
        video.muted = true;
        try {
          await video.play();
        } catch {
          setShowPlayButton(true);
        }
      }
    };
    attemptAutoplay();
  }, []);

  return (
    <section>
      {/* Video hero with overlay text like original */}
      <div className="relative w-full aspect-video md:aspect-auto md:h-screen overflow-hidden bg-foreground">
        <video
          ref={videoRef}
          src={HERO_VIDEO_URL}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/20" />
        {showPlayButton && (
          <button
            onClick={() => { videoRef.current?.play(); setShowPlayButton(false); }}
            className="absolute inset-0 flex items-center justify-center bg-black/50"
          >
            <span className="bg-white text-black px-8 py-4 font-display text-sm uppercase tracking-widest">
              Reproducir
            </span>
          </button>
        )}
      </div>

      {/* Full-width image banners */}
      {banners.map((banner, i) => (
        <div key={i} className="relative w-full h-[60vh] md:h-screen overflow-hidden">
          <img
            src={banner.image}
            alt={banner.title}
            className="w-full h-full object-cover object-center"
            loading={i === 0 ? "eager" : "lazy"}
          />


          <div className="absolute inset-0 bg-black/20" />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
            <h2 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white tracking-tight mb-8">
              {banner.title}
            </h2>
            <a
              href={banner.href}
              className="border border-white/60 text-white px-10 py-4 font-display text-xs font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all duration-300"
            >
              {banner.cta}
            </a>
          </div>
        </div>
      ))}
    </section>
  );
};

export default HeroSection;
