import PunkLogo from "./PunkLogo";

const footerLinks = [
  { label: "Inicio", href: "/" },
  { label: "Catálogo", href: "/#modelos" },
  { label: "Nosotros", href: "/#green" },
  { label: "Servicio al Cliente", href: "/#contacto" },
  { label: "Ser Distribuidor", href: "/#contacto" },
];

const Footer = () => {
  return (
    <footer id="contacto" className="py-16 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        {/* Links */}
        <div className="mb-12">
          {footerLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="block text-foreground hover:underline font-body text-base py-2 transition-colors"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Bottom */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-xs font-body">
            © {new Date().getFullYear()} Punk Electric Argentina
          </p>
          <a
            href="https://www.weego.com.ar"
            target="_blank"
            rel="noopener noreferrer"
            className="text-foreground hover:underline font-body text-xs font-medium"
          >
            Más info en www.weego.com.ar
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
