import detailSuspension from "@/assets/detail-suspension.jpg";
import detailBattery from "@/assets/detail-battery.jpg";
import detailIncline from "@/assets/detail-incline.jpg";

const details = [
  { image: detailSuspension },
  { image: detailBattery },
  { image: detailIncline },
];

const PrecisionSection = () => {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-6">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground text-left mb-12">
          Precisión en cada detalle
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {details.map((d, i) => (
            <div key={i} className="overflow-hidden">
              <img
                src={d.image}
                alt={`Detail ${i + 1}`}
                className="w-full h-auto object-cover"
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PrecisionSection;
