import { products } from "@/data/products";
import { getWhatsAppUrl } from "@/data/products";

const comparisonSpecs = [
  { key: "Resistencia agua", label: "Resistencia al agua" },
  { key: "Batería", label: "Batería" },
  { key: "Ruedas", label: "Neumáticos" },
  { key: "Frenos", label: "Frenos" },
  { key: "Autonomía", label: "Autonomía" },
  { key: "Vel. Máx.", label: "Velocidad máxima" },
  { key: "Peso", label: "Peso" },
  { key: "Carga Máx.", label: "Carga máxima" },
  { key: "Carga", label: "Tiempo de carga" },
  { key: "Motor", label: "Motor" },
  { key: "App", label: "App PUNK" },
  { key: "Bocina", label: "Bocina" },
  { key: "Luces", label: "Luces" },
];

const ComparisonTable = () => {
  // Show main 4 products for comparison (Rider, Rider Pro, Pro Max, Rebel)
  const compareProducts = products.filter(p =>
    ["punk-rider", "punk-rider-pro", "punk-rider-pro-max", "punk-rebel"].includes(p.id)
  );

  return (
    <section id="comparar" className="py-16 bg-background">
      <div className="container mx-auto px-6">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground text-left mb-12">
          Compará modelos
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px]">
            {/* Product headers with images */}
            <thead>
              <tr className="border-b border-border">
                <th className="py-4 px-3 text-left w-1/4"></th>
                {compareProducts.map((p) => (
                  <th key={p.id} className="py-4 px-3 text-center">
                    <div className="flex flex-col items-center">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-32 h-32 object-contain mb-3"
                      />
                      <span className="font-display text-sm font-bold text-foreground uppercase">
                        {p.name}
                      </span>
                      <span className="text-foreground font-body text-base font-bold mt-1">
                        USD {p.price.toLocaleString()}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisonSpecs.map((spec, i) => (
                <tr
                  key={spec.key}
                  className={`border-b border-border/50 ${i % 2 === 0 ? "bg-secondary/30" : ""}`}
                >
                  <td className="py-3 px-3 text-foreground text-sm font-medium font-body">
                    {spec.label}
                  </td>
                  {compareProducts.map((p) => (
                    <td
                      key={p.id}
                      className="py-3 px-3 text-center text-foreground/80 text-sm font-body"
                    >
                      {p.specs[spec.key] || "—"}
                    </td>
                  ))}
                </tr>
              ))}
              {/* CTA row */}
              <tr>
                <td className="py-6 px-3"></td>
                {compareProducts.map((p) => (
                  <td key={p.id} className="py-6 px-3 text-center">
                    <a
                      href={getWhatsAppUrl(p)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block bg-foreground text-background px-6 py-2.5 font-body text-xs font-medium uppercase tracking-widest hover:opacity-80 transition-opacity"
                    >
                      Comprar
                    </a>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ComparisonTable;
