import { Zap, Shield, Battery, Gauge, Wrench, Leaf } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Potencia Eléctrica",
    description: "Motores de alta eficiencia que entregan potencia instantánea y aceleración suave.",
  },
  {
    icon: Battery,
    title: "Batería de Larga Duración",
    description: "Celdas de litio de última generación con autonomías de hasta 80 km por carga.",
  },
  {
    icon: Gauge,
    title: "Velocidad Premium",
    description: "Hasta 65 km/h en nuestro modelo tope de gama. Potencia cuando la necesitás.",
  },
  {
    icon: Shield,
    title: "Seguridad Total",
    description: "Frenos hidráulicos, luces LED integradas y sistema de bloqueo electrónico.",
  },
  {
    icon: Wrench,
    title: "Servicio Técnico",
    description: "Red de servicio oficial en Argentina. Repuestos originales y garantía extendida.",
  },
  {
    icon: Leaf,
    title: "Movilidad Sustentable",
    description: "Cero emisiones, cero ruido. Contribuí a un futuro más limpio con cada viaje.",
  },
];

const FeaturesSection = () => {
  return (
    <section id="caracteristicas" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-primary font-display text-xs tracking-[0.3em] uppercase mb-3">
            Ventajas
          </p>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground">
            ¿Por qué PUNK?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="group p-8 bg-card border border-border hover:border-primary/40 transition-all duration-500 animate-fade-up"
              style={{ animationDelay: `${i * 0.1}s`, opacity: 0 }}
            >
              <div className="w-12 h-12 bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                <f.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-bold text-foreground mb-3">{f.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed font-body">{f.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
