import { useState, useEffect } from "react";
import { Menu, X, Search, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import PunkLogo from "./PunkLogo";

const navLinks = [
  { label: "Inicio", href: "/" },
  { label: "Productos", href: "/#modelos" },
  { label: "Nosotros", href: "/#green" },
  { label: "Contacto", href: "/#contacto" },
];

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/95 backdrop-blur-xl border-b border-border shadow-sm"
          : "bg-background border-b border-border"
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between h-16">
        {/* Mobile menu toggle */}
        <button
          className="md:hidden text-foreground"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        {/* Left nav links (desktop) */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-xs font-medium text-foreground/80 hover:text-foreground transition-colors tracking-wide uppercase font-body"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Center logo */}
        <Link to="/" className="absolute left-1/2 -translate-x-1/2">
          <PunkLogo className="h-7 w-auto" dark={true} />
        </Link>

        {/* Right icons */}
        <div className="flex items-center gap-4">
          <button className="text-foreground/80 hover:text-foreground transition-colors" aria-label="Buscar">
            <Search size={20} />
          </button>
          <a href="/#modelos" className="text-foreground/80 hover:text-foreground transition-colors" aria-label="Tienda">
            <ShoppingBag size={20} />
          </a>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-background border-b border-border">
          <div className="container mx-auto px-6 py-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-base font-medium text-foreground/80 hover:text-foreground transition-colors uppercase tracking-wide font-body"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
