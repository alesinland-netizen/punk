type Props = { className?: string; dark?: boolean };

const PunkLogo = ({ className = "", dark = true }: Props) => {
  return (
    <img
      src="/brand/Logo-dark_png.webp"   // ← EXACTO como tu archivo (L mayúscula)
      alt="PUNK"
      className={className}
      style={{
        display: "block",
        height: "28px",
        width: "auto",
        objectFit: "contain",
        filter: dark ? "none" : "invert(1)",
      }}
      draggable={false}
    />
  );
};

export default PunkLogo;
