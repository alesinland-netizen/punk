import { ArrowRight } from "lucide-react";

const AnnouncementBar = () => {
  return (
    <div className="bg-secondary border-b border-border py-2.5">
      <div className="container mx-auto px-6 text-center">
        <a
          href="/products/punk-rider-pro"
          className="text-foreground/80 hover:text-foreground text-xs font-body tracking-wide inline-flex items-center gap-2 transition-colors"
        >
          ¡Descubrí el Rider Pro! EL nuevo referente en movilidad eléctrica
          <ArrowRight size={14} />
        </a>
      </div>
    </div>
  );
};

export default AnnouncementBar;
