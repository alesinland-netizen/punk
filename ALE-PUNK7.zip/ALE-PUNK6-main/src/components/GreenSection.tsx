import greenImage from "@/assets/green-movement.jpg";

const GreenSection = () => {
  return (
    <section id="green" className="py-16 bg-background">
      <div className="container mx-auto px-6">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground text-left mb-12">
          Sumate al movimiento verde
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 items-stretch">
          <div className="overflow-hidden">
            <img
              src={greenImage}
              alt="One Tree Planted"
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>

          <div className="bg-foreground text-background p-10 md:p-16 flex flex-col justify-center">
            <p className="text-background/60 font-body text-xs tracking-[0.3em] uppercase mb-3">
              Green Punk
            </p>
            <h3 className="font-display text-2xl md:text-3xl font-bold mb-6">
              Join Our Fight
            </h3>
            <p className="text-background/80 text-sm leading-relaxed font-body max-w-md">
              At Punk Electric, we are committed to preserving our planet. Our electric scooters reduce carbon emissions and promote sustainable urban mobility.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GreenSection;
