import { Link } from "react-router-dom";
import { products } from "@/data/products";

const ProductsSection = () => {
  return (
    <section id="modelos" className="py-16 bg-background">
      <div className="container mx-auto px-6">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground text-left mb-12">
          Descubrí los productos Punk Electric
        </h2>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/products/${product.slug}`}
              className="group block"
            >
              <div className="relative aspect-square overflow-hidden bg-secondary mb-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                {product.gallery[1] && (
                  <img
                    src={product.gallery[1]}
                    alt={`${product.name} alt`}
                    className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    loading="lazy"
                  />
                )}
              </div>
              <h3 className="font-body text-sm font-medium text-foreground mb-1">
                {product.name}
              </h3>
              <p className="text-foreground font-body text-sm font-semibold">
                USD {product.price.toLocaleString()}
              </p>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="#modelos"
            className="inline-block border border-foreground text-foreground px-10 py-3 font-body text-sm uppercase tracking-wider hover:bg-foreground hover:text-background transition-all"
          >
            Ver todos
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;
