import { Product, getWhatsAppUrl } from "@/data/products";

interface ProductCardProps {
  product: Product;
  index: number;
}

const ProductCard = ({ product, index }: ProductCardProps) => {
  return (
    <div
      className="group relative bg-card border border-border hover:border-primary/50 transition-all duration-500 overflow-hidden animate-fade-up"
      style={{ animationDelay: `${index * 0.15}s`, opacity: 0 }}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-secondary">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="p-6">
        <p className="text-primary text-xs font-display tracking-[0.2em] uppercase mb-2">
          {product.tagline}
        </p>
        <h3 className="font-display text-xl font-bold text-foreground mb-2">
          {product.name}
        </h3>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2 font-body">
          {product.description}
        </p>

        {/* Price */}
        <div className="flex items-end justify-between mb-4">
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wider">Desde</p>
            <p className="font-display text-2xl font-bold text-foreground">
              USD <span className="text-primary">{product.price.toLocaleString()}</span>
            </p>
          </div>
        </div>

        {/* Quick specs */}
        <div className="grid grid-cols-2 gap-2 mb-6">
          {Object.entries(product.specs).slice(0, 4).map(([key, val]) => (
            <div key={key} className="bg-secondary/50 px-3 py-2">
              <p className="text-muted-foreground text-[10px] uppercase tracking-wider">{key}</p>
              <p className="text-foreground text-sm font-semibold">{val}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <a
          href={getWhatsAppUrl(product)}
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full bg-primary text-primary-foreground text-center py-3 font-display text-xs font-bold uppercase tracking-widest hover:shadow-punk transition-all"
        >
          Comprar por WhatsApp
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
