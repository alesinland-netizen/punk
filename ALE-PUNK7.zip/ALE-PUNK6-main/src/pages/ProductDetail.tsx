import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { products, getWhatsAppUrl } from "@/data/products";
import { ChevronLeft, Minus, Plus, Share2 } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import AnnouncementBar from "@/components/AnnouncementBar";

const ProductDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const product = products.find((p) => p.slug === slug);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-4xl font-bold text-foreground mb-4">Producto no encontrado</h1>
          <Link to="/" className="text-foreground hover:underline font-body">Volver al inicio</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />

      <main className="pt-28 pb-24">
        <div className="container mx-auto px-6">
          <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm font-body mb-8 transition-colors">
            <ChevronLeft size={16} />
            Volver a productos
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Gallery */}
            <div>
              <div className="aspect-square bg-secondary overflow-hidden mb-4">
                <img
                  src={product.gallery[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {product.gallery.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {product.gallery.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImage(i)}
                      className={`aspect-square bg-secondary overflow-hidden border-2 transition-colors ${
                        i === selectedImage ? "border-foreground" : "border-transparent"
                      }`}
                    >
                      <img src={img} alt={`${product.name} ${i + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Product info */}
            <div>
              <p className="text-muted-foreground text-xs uppercase tracking-[0.2em] font-body mb-2">
                Punk Electric
              </p>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                {product.name}
              </h1>

              <div className="flex items-baseline gap-3 mb-2">
                <span className="text-foreground text-2xl font-body font-bold">
                  USD {product.price.toLocaleString()}
                </span>
              </div>
              <p className="text-muted-foreground text-xs font-body mb-6">Impuestos incluidos.</p>

              {/* Quantity */}
              <div className="mb-6">
                <p className="text-sm text-foreground font-body mb-2">Cantidad</p>
                <div className="flex items-center border border-border w-fit">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-3 text-foreground hover:text-muted-foreground transition-colors"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="px-6 text-foreground font-body">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-3 text-foreground hover:text-muted-foreground transition-colors"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* CTA */}
              <a
                href={getWhatsAppUrl(product)}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-foreground text-background text-center py-4 font-body text-sm font-medium uppercase tracking-widest hover:opacity-80 transition-opacity mb-4"
              >
                Comprar por WhatsApp
              </a>

              {/* Description */}
              <div className="mt-8 mb-8">
                <p className="text-muted-foreground text-sm leading-relaxed font-body">
                  {product.description}
                </p>
              </div>

              {/* Features */}
              {product.features.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-foreground font-bold text-sm font-body mb-3">
                    ¿Por qué elegir el {product.name}?
                  </h3>
                  <ul className="space-y-2">
                    {product.features.map((f, i) => (
                      <li key={i} className="text-muted-foreground text-sm font-body flex items-start gap-2">
                        <span className="text-foreground mt-1">•</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Specs */}
              <div className="mb-8">
                <h3 className="text-foreground font-bold text-sm font-body mb-3">
                  Información Técnica:
                </h3>
                <div className="space-y-2">
                  {Object.entries(product.specs).map(([key, val]) => (
                    <div key={key} className="flex justify-between text-sm font-body border-b border-border/50 pb-2">
                      <span className="text-muted-foreground">{key}</span>
                      <span className="text-foreground font-medium">{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Share */}
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm font-body transition-colors">
                <Share2 size={16} />
                Compartir
              </button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default ProductDetail;
