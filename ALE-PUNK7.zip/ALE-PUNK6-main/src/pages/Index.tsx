import Navbar from "@/components/Navbar";
import AnnouncementBar from "@/components/AnnouncementBar";
import HeroSection from "@/components/HeroSection";
import PrecisionSection from "@/components/PrecisionSection";
import GreenSection from "@/components/GreenSection";
import ProductsSection from "@/components/ProductsSection";
import ComparisonTable from "@/components/ComparisonTable";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Navbar />
      <div className="pt-16">
        <HeroSection />
        <PrecisionSection />
        <GreenSection />
        <ProductsSection />
        <ComparisonTable />
      </div>
      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Index;
