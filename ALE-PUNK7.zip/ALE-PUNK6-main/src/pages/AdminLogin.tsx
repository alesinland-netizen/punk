import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import PunkLogo from "@/components/PunkLogo";

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });

    if (authError) {
      setError("Credenciales inválidas");
      setLoading(false);
      return;
    }

    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .eq("role", "admin")
      .maybeSingle();

    if (!roleData) {
      setError("No tenés permisos de administrador");
      await supabase.auth.signOut();
      setLoading(false);
      return;
    }

    navigate("/admin");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="flex justify-center mb-8">
          <PunkLogo className="h-8 w-auto" dark={true} />
        </div>
        <p className="text-muted-foreground text-sm text-center mb-8 font-body">
          Panel de Administración
        </p>

        <form onSubmit={handleLogin} className="space-y-4">
          {error && (
            <div className="bg-destructive/10 text-destructive text-sm p-3 font-body">
              {error}
            </div>
          )}
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required className="w-full border border-border bg-background text-foreground px-4 py-3 text-sm font-body placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground" />
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Contraseña" required className="w-full border border-border bg-background text-foreground px-4 py-3 text-sm font-body placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground" />
          <button type="submit" disabled={loading} className="w-full bg-foreground text-background py-3 font-body text-sm font-medium uppercase tracking-widest hover:opacity-80 transition-opacity disabled:opacity-50">
            {loading ? "Ingresando..." : "Ingresar"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
