import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { LogOut, Plus, Pencil, Trash2, Eye, EyeOff, Image } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";
import PunkLogo from "@/components/PunkLogo";

type Product = Tables<"products">;

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState({
    name: "",
    slug: "",
    price: 0,
    currency: "USD",
    description: "",
    tagline: "",
    featured: false,
    published: true,
    active: true,
    image_url: "",
    sku: "",
    stock: 0,
    sort_order: 0,
  });

  useEffect(() => {
    checkAuth();
    fetchProducts();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { navigate("/admin/login"); return; }
    const { data: role } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!role) { await supabase.auth.signOut(); navigate("/admin/login"); }
  };

  const fetchProducts = async () => {
    const { data } = await supabase.from("products").select("*").order("sort_order");
    setProducts(data || []);
    setLoading(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/admin/login");
  };

  const resetForm = () => {
    setForm({ name: "", slug: "", price: 0, currency: "USD", description: "", tagline: "", featured: false, published: true, active: true, image_url: "", sku: "", stock: 0, sort_order: 0 });
    setEditingProduct(null);
    setShowForm(false);
  };

  const openEdit = (product: Product) => {
    setForm({
      name: product.name, slug: product.slug, price: Number(product.price), currency: product.currency,
      description: product.description || "", tagline: product.tagline || "", featured: product.featured,
      published: product.published, active: product.active, image_url: product.image_url || "",
      sku: product.sku || "", stock: product.stock || 0, sort_order: product.sort_order,
    });
    setEditingProduct(product);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (editingProduct) {
      await supabase.from("products").update(form).eq("id", editingProduct.id);
    } else {
      await supabase.from("products").insert(form);
    }
    resetForm();
    fetchProducts();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar este producto?")) return;
    await supabase.from("products").delete().eq("id", id);
    fetchProducts();
  };

  const togglePublished = async (product: Product) => {
    await supabase.from("products").update({ published: !product.published }).eq("id", product.id);
    fetchProducts();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground font-body">Cargando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-background">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <PunkLogo className="h-6 w-auto" dark={true} />
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground font-body">Admin</span>
            <button onClick={handleLogout} className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm font-body transition-colors">
              <LogOut size={16} /> Salir
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-display text-2xl font-bold text-foreground">Productos</h2>
          <button onClick={() => { resetForm(); setShowForm(true); }} className="flex items-center gap-2 bg-foreground text-background px-4 py-2 font-body text-xs font-medium uppercase tracking-widest hover:opacity-80 transition-opacity">
            <Plus size={16} /> Nuevo
          </button>
        </div>

        {showForm && (
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-background border border-border p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-lg">
              <h3 className="font-display text-lg font-bold text-foreground mb-4">
                {editingProduct ? "Editar Producto" : "Nuevo Producto"}
              </h3>
              <div className="space-y-3">
                <input placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground" />
                <input placeholder="Slug (URL)" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground" />
                <div className="grid grid-cols-2 gap-3">
                  <input type="number" placeholder="Precio" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body" />
                  <input placeholder="Moneda" value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body" />
                </div>
                <input placeholder="Tagline" value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body placeholder:text-muted-foreground" />
                <textarea placeholder="Descripción" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body placeholder:text-muted-foreground resize-none" />
                <input placeholder="URL Imagen principal" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body placeholder:text-muted-foreground" />
                <div className="grid grid-cols-2 gap-3">
                  <input placeholder="SKU" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body" />
                  <input type="number" placeholder="Stock" value={form.stock} onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })} className="w-full border border-border bg-background text-foreground px-3 py-2 text-sm font-body" />
                </div>
                <div className="flex items-center gap-6">
                  <label className="flex items-center gap-2 text-sm text-foreground font-body cursor-pointer">
                    <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Destacado
                  </label>
                  <label className="flex items-center gap-2 text-sm text-foreground font-body cursor-pointer">
                    <input type="checkbox" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} /> Publicado
                  </label>
                  <label className="flex items-center gap-2 text-sm text-foreground font-body cursor-pointer">
                    <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Activo
                  </label>
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={handleSave} className="flex-1 bg-foreground text-background py-2 font-body text-xs font-medium uppercase tracking-widest hover:opacity-80 transition-opacity">
                  {editingProduct ? "Guardar" : "Crear"}
                </button>
                <button onClick={resetForm} className="flex-1 border border-border text-foreground py-2 font-body text-xs font-medium uppercase tracking-widest hover:bg-secondary transition-colors">
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-3 text-xs text-muted-foreground uppercase tracking-wider font-body">Producto</th>
                <th className="text-left py-3 px-3 text-xs text-muted-foreground uppercase tracking-wider font-body">Precio</th>
                <th className="text-left py-3 px-3 text-xs text-muted-foreground uppercase tracking-wider font-body">Estado</th>
                <th className="text-right py-3 px-3 text-xs text-muted-foreground uppercase tracking-wider font-body">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-3">
                      {p.image_url ? (
                        <img src={p.image_url} alt={p.name} className="w-10 h-10 object-cover bg-secondary" />
                      ) : (
                        <div className="w-10 h-10 bg-secondary flex items-center justify-center"><Image size={16} className="text-muted-foreground" /></div>
                      )}
                      <div>
                        <p className="text-foreground text-sm font-medium font-body">{p.name}</p>
                        <p className="text-muted-foreground text-xs font-body">{p.slug}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-foreground text-sm font-body">{p.currency} {Number(p.price).toLocaleString()}</td>
                  <td className="py-3 px-3">
                    <span className={`text-xs px-2 py-1 font-body ${p.published ? "bg-green-100 text-green-800" : "bg-secondary text-muted-foreground"}`}>
                      {p.published ? "Publicado" : "Borrador"}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => togglePublished(p)} className="p-1.5 text-muted-foreground hover:text-foreground transition-colors">
                        {p.published ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                      <button onClick={() => openEdit(p)} className="p-1.5 text-muted-foreground hover:text-foreground transition-colors">
                        <Pencil size={16} />
                      </button>
                      <button onClick={() => handleDelete(p.id)} className="p-1.5 text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr><td colSpan={4} className="py-12 text-center text-muted-foreground font-body">No hay productos.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
