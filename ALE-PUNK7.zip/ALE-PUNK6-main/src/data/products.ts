import scooterRider from "@/assets/product-rider.png";
import scooterPro from "@/assets/product-rider-pro.png";
import scooterProMax from "@/assets/product-promax.jpg";
import scooterRebel from "@/assets/product-rebel.jpg";

// Gallery images
import riderGallery2 from "@/assets/gallery/rider-2.png";
import riderProGallery2 from "@/assets/gallery/rider-pro-2.png";
import riderProGallery3 from "@/assets/gallery/rider-pro-3.png";
import riderProGallery4 from "@/assets/gallery/rider-pro-4.png";
import riderProGallery5 from "@/assets/gallery/rider-pro-5.png";
import riderProGallery6 from "@/assets/gallery/rider-pro-6.png";
import riderProGallery7 from "@/assets/gallery/rider-pro-7.png";
import rebelGallery2 from "@/assets/gallery/rebel-2.jpg";
import promaxGallery2 from "@/assets/gallery/promax-2.jpg";

export interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  originalPrice?: number;
  currency: string;
  image: string;
  gallery: string[];
  tagline: string;
  description: string;
  features: string[];
  specs: Record<string, string>;
  featured: boolean;
}

export const products: Product[] = [
  {
    id: "punk-rider",
    name: "Punk Rider",
    slug: "punk-rider",
    price: 1299,
    currency: "USD",
    image: scooterRider,
    gallery: [scooterRider, riderGallery2],
    tagline: "Tu primer paso eléctrico",
    description: "El modelo ideal para comenzar tu experiencia eléctrica. Compacto, ágil y con la potencia justa para la ciudad.",
    features: [
      "Frenos hidráulicos",
      "App Punk conectada",
      "Bocina y luces de stop/giro",
      "Resistencia al agua IPX5",
      "Neumáticos autosellantes",
    ],
    specs: {
      "Motor": "800W",
      "Batería": "48V 15.6Ah",
      "Autonomía": "45 km",
      "Vel. Máx.": "40 km/h",
      "Peso": "18 kg",
      "Ruedas": "10\"",
      "Frenos": "Hidráulico",
      "Carga Máx.": "120 kg",
      "App": "Sí",
      "Bocina": "Sí",
      "Luces": "Stop y Giro",
    },
    featured: false,
  },
  {
    id: "punk-rider-pro",
    name: "Punk Rider Pro",
    slug: "punk-rider-pro",
    price: 1750,
    currency: "USD",
    image: scooterPro,
    gallery: [scooterPro, riderProGallery2, riderProGallery3, riderProGallery4, riderProGallery5, riderProGallery6, riderProGallery7],
    tagline: "Potencia sin compromisos",
    description: "Descubrí el scooter eléctrico Punk Rider Pro. Una innovación revolucionaria en el ecosistema de movilidad eléctrica urbana.",
    features: [
      "2 motores de 800W",
      "Frenos hidráulicos",
      "App Punk conectada",
      "Bocina y luces de stop/giro",
      "Resistencia al agua extrema IPX6",
      "Suspensión avanzada",
    ],
    specs: {
      "Motor": "2x 800W",
      "Batería": "52V 18.2Ah",
      "Autonomía": "50 km",
      "Vel. Máx.": "50 km/h",
      "Peso": "31 kg",
      "Ruedas": "10 x 3 inch",
      "Frenos": "Hidráulico + Regenerativo",
      "Carga Máx.": "120 kg",
      "Resistencia agua": "IPX6",
      "Carga": "9 hrs",
      "App": "Sí",
      "Bocina": "Sí",
      "Luces": "Stop y Giro",
    },
    featured: true,
  },
  {
    id: "punk-rider-pro-max",
    name: "Punk Rider Pro Max",
    slug: "punk-rider-pro-max",
    price: 1950,
    currency: "USD",
    image: scooterProMax,
    gallery: [scooterProMax, promaxGallery2],
    tagline: "El tope de gama urbano",
    description: "La máxima expresión de movilidad eléctrica urbana. Batería de largo alcance, motor potente y suspensión premium.",
    features: [
      "2 motores de 800W",
      "Frenos hidráulicos NUTT",
      "App Punk conectada",
      "Bocina y luces de stop/giro",
      "Suspensión premium",
      "Autonomía extendida",
    ],
    specs: {
      "Motor": "2x 800W",
      "Batería": "52V 20Ah",
      "Autonomía": "60 km",
      "Vel. Máx.": "50 km/h",
      "Peso": "31 kg",
      "Ruedas": "10 x 3 inch",
      "Frenos": "Hidráulico (NUTT) + Regenerativo",
      "Carga Máx.": "120 kg",
      "Resistencia agua": "IPX6",
      "Carga": "9 hrs",
      "App": "Sí",
      "Bocina": "Sí",
      "Luces": "Stop y Giro",
    },
    featured: false,
  },
  {
    id: "punk-rebel",
    name: "Punk Rebel",
    slug: "punk-rebel",
    price: 2400,
    currency: "USD",
    image: scooterRebel,
    gallery: [scooterRebel, rebelGallery2],
    tagline: "Sin límites. Sin reglas.",
    description: "Diseñado para los más exigentes. Potencia bruta de 2400W, suspensión off-road y frenos NUTT. (Precio varía según batería)",
    features: [
      "2 motores de 1200W",
      "Frenos hidráulicos NUTT",
      "Velocidad Máx. 70 km/h",
      "Autonomía hasta 100km",
      "Suspensión off-road",
      "Construcción robusta",
    ],
    specs: {
      "Motor": "2x 1200W",
      "Batería": "60V (Varios tamaños)",
      "Autonomía": "100 km",
      "Vel. Máx.": "70 km/h",
      "Peso": "38 kg / 40 kg",
      "Ruedas": "11 x 3.5 inch",
      "Frenos": "Hidráulico (NUTT) + Regenerativo",
      "Carga Máx.": "130 kg",
      "Resistencia agua": "IPX6",
      "Carga": "11/15 hrs",
      "App": "Opcional",
      "Bocina": "Sí",
      "Luces": "Stop y Giro",
    },
    featured: false,
  },
];

export function getWhatsAppUrl(product: Product): string {
  const phone = "5491161937808";
  const message = encodeURIComponent(
    `Hola, quiero comprar el siguiente modelo:\n🛴 Modelo: ${product.name}\n💵 Precio: USD ${product.price}\n¿Tienen stock? ¿Formas de pago?`
  );
  return `https://wa.me/${phone}?text=${message}`;
}
